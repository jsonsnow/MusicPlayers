//
//  CLMusicGroup.h
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/22.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CLMusicGroup : NSObject
@property (nonatomic,strong) NSString *titile;
@property (nonatomic,strong) NSMutableArray  *musicsArray;

@end
