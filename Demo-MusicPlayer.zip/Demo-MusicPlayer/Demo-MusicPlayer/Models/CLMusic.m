//
//  CLMusic.m
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/4.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import "CLMusic.h"

@implementation CLMusicOnBaiDu



@end

@implementation CLMusic



@end

@implementation CLMusicOnlie



@end

@implementation CLMusicOnBaiDuIcon
-(NSString *)description{
    
    return [NSString stringWithFormat:@"%@  %@",_songName,_artistName];   
}


@end

@implementation CLMusicOnBaiDuList



@end