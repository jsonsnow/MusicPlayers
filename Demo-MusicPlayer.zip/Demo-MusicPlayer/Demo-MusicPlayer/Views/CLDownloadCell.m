//
//  CLDownloadCell.m
//  Demo-MusicPlayer
//
//  Created by Aspmcll on 16/1/23.
//  Copyright © 2016年 Aspmcll. All rights reserved.
//

#import "CLDownloadCell.h"

@implementation CLDownloadCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
